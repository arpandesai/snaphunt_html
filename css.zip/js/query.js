$(document).ready(function() {
	$('.fixed_textarea').scroll(function () {
	    $(this).css("overflow", "hidden");      /* for the mozilla browser problem */
	    $(this).animate({scrollTop: $(this).outerHeight()});
	    while ($(this).scrollTop() > 0) {       /* for the copy and paste case */               
	        lines=$(this).val().slice(0,-1);
	        $(this).val(lines);
	    }
	    $(this).css("overflow", "auto");        /* For the mozilla browser problem */
	});
	
	$(document).on("click",".color_change_on_click",function(){
		$(".color_change_on_click").css("background-color","lightgray");
		$(".icon_color").css("background-color","lightgray");
		$(".container").css("background-color","lightgray");
    $(".input-group-addon").css("background-color","lightgray!important");
		$(".user_photo").css("opacity","0.2");
    $(".delete_icon").css("display","none");
    $(this).find(".delete_icon").css("display","block");
		$(this).css("background-color","white");
		$(this).find(".icon_color").css("background-color","white");
    $(this).find(".user_photo").css("opacity","10");
	});

	$(".color_change_on_click").mouseenter(function() {
	    $(this).css("border","1px solid darkgray");
	}).mouseleave(function() {
	     $(this).css("border", "1px solid transparent");
	});


	$(".container").click(function(){
    $(".delete_icon").css("display","none");
		$(".color_change_on_click").css("background-color","white");
		$(".icon_color").css("background-color","white");
		$(".container").css("background-color","white");
	});
	$("body").click(function(){
    $(".delete_icon").css("display","none");
		$(".color_change_on_click").css("background-color","white");
		$(".icon_color").css("background-color","white");
		$(".container").css("background-color","white");
	});
	$(document).on('click','.del_achivement',function(){
		$("#"+$("#delete_div").val()).remove();
	});

	deleteDivById();

	$('[data-toggle="popover"]').popover({
        placement : 'top',
        html : true,
        content : '<i class="fa fa-plus" id="add_achivement" aria-hidden="true"></i><i class="fa fa-trash del_achivement" rel="" aria-hidden="true"></i>'
    });

    $(document).on("click", ".popover .close" , function(){
        $(this).parents(".popover").popover('hide');
    });
});

function deleteDivById(){
	$('[data-toggle="popover"]').on('show.bs.popover', function () {
		if($(this).hasClass('div_heading')==true){
			$("#delete_div").val($(this).parent().attr('id'));
		}
		else{
			$("#delete_div").val(this.id);
		}	

	});
}

$(function(){
  var ac_count =ed_count=la_count=in_count = ex_count= 2;
  $(document).on('click','#add_achivement',function(){
  	var div_name = $("#delete_div").val();
    var new_div = '';
    $(".container").css("background-color","lightgray");
  	$(".color_change_on_click").css("background-color","lightgray");
    $(".icon_color").css("background-color","lightgray");
  	if(div_name.indexOf('achivement_div')!= -1)
  	{
  		$('.achivement_main_div').append('<div class="input-group color_change_on_click width100" id="achivement_div'+ac_count+'" data-trigger="focus" data-toggle="popover"><span class="input-group-addon"><i class="fa fa-trophy icon_color" aria-hidden="true"></i></span><textarea rows="2" placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor." class="form-control background_transparent fixed_textarea textarea_with_icon" class="form-control background_transparent fixed_textarea " onkeydown="return limitLines(this, event)"></textarea></div><hr class="div_single_border"/>');
  			                       							  		
  		$('#achivement_div'+ac_count).popover({
        placement : 'top',
        html : true,
        content : '<i class="fa fa-plus" id="add_achivement" aria-hidden="true"></i><i class="fa fa-trash del_achivement" aria-hidden="true"></i>'
      });
      $('#achivement_div'+ac_count).css("background-color","white");
      new_div = '#achivement_div'+ac_count;
  		ac_count++;
  	}
  	else if(div_name.indexOf('education_div')!= -1)
  	{
  		$('.education_main_div').append('<div id="education_div'+ed_count+'" class="color_change_on_click"  data-trigger="focus" data-toggle="popover"><div class="float_left width60"><textarea class="form-control background_transparent fixed_textarea" rows="2" placeholder="Education Details" required ></textarea></div><div class="width32 float_right"><div class="input-group"><input type="text" id="date'+ed_count+'" name="testdate" class="form-control datepicker background_transparent" value="" placeholder="date"><label class="input-group-addon padding_left0 background_transparent " for="date'+ed_count+'"><svg class="lnr lnr-calendar-full"><use xlink:href="#lnr-calendar-full"></use></svg></label></div></div><div class="clearfix"></div><hr class="div_single_border"/>');
  		$('#education_div'+ed_count).popover({
        placement : 'top',
        html : true,
        content : '<i class="fa fa-plus" id="add_achivement" aria-hidden="true"></i><i class="fa fa-trash del_achivement" aria-hidden="true"></i>'
      });
      $('.datepicker,.lnr-calendar-full').datepicker();
      $('#education_div'+ed_count).css("background-color","white");
      new_div = '#education_div'+ed_count;
  		ed_count++;
	  }
    else if(div_name.indexOf('languages_div')!= -1)
  	{
  		$('.languages_main_div').append('<div id="languages_div'+la_count+'" class="color_change_on_click"  data-trigger="focus" data-toggle="popover"><div class="float_left width50"><textarea class="form-control background_transparent fixed_textarea" rows="1" placeholder="Name" required ></textarea></div><div class="float_right width50"><textarea placeholder="Level" class="form-control background_transparent fixed_textarea" rows="1" onkeydown="return limitLines(this, event)" required ></textarea></div><div class="clearfix"></div></div><hr class="div_single_border"/> ');
      $('#languages_div'+la_count).popover({
        placement : 'top',
        html : true,
        content : '<i class="fa fa-plus" id="add_achivement" aria-hidden="true"></i><i class="fa fa-trash del_achivement" aria-hidden="true"></i>'
      });
      $('#languages_div'+la_count).css("background-color","white");
      new_div = '#languages_div'+la_count;
  		la_count++;
	  }
    else if(div_name.indexOf('interests_div')!= -1)
    {
      $('.interests_main_div').append('<div id="interests_div'+in_count+'" class="input-group color_change_on_click"  data-trigger="focus" data-toggle="popover"><span class="input-group-addon"><i class="fa fa-star icon_color" aria-hidden="true"></i></span><textarea rows="2" placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor." class="form-control background_transparent fixed_textarea textarea_with_icon" class="form-control background_transparent fixed_textarea " onkeydown="return limitLines(this, event)"></textarea></div><hr class="div_single_border"/>');       
      $('#interests_div'+in_count).popover({
        placement : 'top',
        html : true,
        content : '<i class="fa fa-plus" id="add_achivement" aria-hidden="true"></i><i class="fa fa-trash del_achivement" aria-hidden="true"></i>'
      });
      $('#interests_div'+in_count).css("background-color","white");
      new_div = '#interests_div'+in_count;
      in_count++;
    }
    else if(div_name.indexOf('experience_div')!= -1)
    {
      $('.experience_main_div').append('<div id="experience_div'+ex_count+'" class="color_change_on_click"  data-trigger="focus" data-toggle="popover"><div class="float_left width80"><textarea placeholder="Software" class="form-control background_transparent fixed_textarea company_name" rows="1" onkeydown="return limitLines(this, event)" required></textarea></div><div class="float_right width16"><div class="input-group"><input type="text" id="date3" name="testdate" class="form-control datepicker background_transparent" value="01/01/2000"><label class="input-group-addon padding_left0 background_transparent" for="date3"><svg class="lnr lnr-calendar-full calendar_icon"><use xlink:href="#lnr-calendar-full"></use></svg></label>     </div></div><div class="clearfix"></div><div><textarea placeholder="ABC Limitd" class="form-control background_transparent fixed_textarea position_name" rows="1" onkeydown="return limitLines(this, event)" required ></textarea> </div><div><div class="input-group width100"><div class="col-lg-1 company_add_div"><svg class="lnr lnr-map-marker icon_color heading_3_icons"><use xlink:href="#lnr-map-marker"></use></svg></div><div class="col-lg-11 padding_left0"><textarea placeholder="safilo far east, Hong Kong" class="form-control background_transparent fixed_textarea " rows="1" onkeydown="return limitLines(this, event)" required ></textarea></div></div></div><div><textarea placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum." class="form-control background_transparent fixed_textarea" rows="4" required ></textarea></div></div><hr class="div_single_border"/>');
      $('#experience_div'+ex_count).popover({
        placement : 'top',
        html : true,
        content : '<i class="fa fa-plus" id="add_achivement" aria-hidden="true"></i><i class="fa fa-trash del_achivement" aria-hidden="true"></i>'
      });
      $('.datepicker,.lnr-calendar-full').datepicker();
      $('#experience_div'+ex_count).css("background-color","white");
      new_div = '#experience_div'+ex_count;
      ex_count++;
    }
    $('html, body').animate({
        scrollTop: $(new_div).offset().top}, 1500);
    deleteDivById();
  });
});

$( function() {
    $('.datepicker,.lnr-calendar-full').datepicker();
  } );

