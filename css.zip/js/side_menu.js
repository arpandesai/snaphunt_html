function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

/* Set the width of the side navigation to 0 */
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
function deleteDivById(){
	$('[data-toggle="popover"]').on('show.bs.popover', function () {
		if($(this).hasClass('div_heading')==true){
			$("#delete_div").val($(this).parent().attr('id'));
		}
		else{
			$("#delete_div").val(this.id);
		}	

	});
}

$(document).ready(function(){
	var ac_count =ed_count=la_count=in_count = ex_count= 0;
	var new_div = '';
    	$('[data-toggle="popover"]').popover({
        placement : 'top',
        html : true,
        content : '<i class="fa fa-plus" id="add_achivement" aria-hidden="true"></i><i class="fa fa-trash del_achivement" rel="" aria-hidden="true"></i>'
    });

    $(document).on("click", ".popover .close" , function(){
        $(this).parents(".popover").popover('hide');
    });

	$('#addAchi').click(function() {
		if(document.getElementById("achivement_div") == null)
		{
			var $firstprice=$(".originalAchivementDiv");
			var $newpricetype=$firstprice.clone();
			//console.log($newpricetype.find(".achivement_main_div .originalArchi").length);
			$newpricetype.find(".achivement_main_div_sample").attr("class","achivement_main_div");
			
			$(".add_newdiv").append($newpricetype.fadeIn());
			$newpricetype.find(".achivement_main_div .originalArchi").each(function(){
				this.id = "achivement_div"+ac_count;
				$('#achivement_div'+ac_count).popover
				({
				    placement : 'top',
				    html : true,
				    content : '<i class="fa fa-plus" id="add_achivement" aria-hidden="true"></i><i class="fa fa-trash del_achivement" aria-hidden="true"></i>'
				});
				$('#achivement_heading').popover
				({
				    placement : 'top',
				    html : true,
				    content : '<i class="fa fa-plus" id="add_achivement" aria-hidden="true"></i><i class="fa fa-trash del_achivement" aria-hidden="true"></i>'
				});
				new_div = '#achivement_div'+ac_count;
				ac_count++;	
			});
			$('html, body').animate({scrollTop: $(new_div).offset().top}, 1500);
			deleteDivById();
		}
		else
		{
			alert("Already there");		
		}
	});

	$('#addEduc').click(function() {
		if(document.getElementById("education_div") == null)
		{
			var $firstprice=$(".originalEducationDiv");
			var $newpricetype=$firstprice.clone();
			//console.log($newpricetype.find(".achivement_main_div .originalArchi").length);
			$newpricetype.find(".education_main_div_sample").attr("class","education_main_div");
			
			$(".add_newdiv").append($newpricetype.fadeIn());
			$newpricetype.find(".education_main_div .originalArchi").each(function(){
				this.id = "education_div"+ac_count;
				$('#education_div'+ac_count).popover
				({
				    placement : 'top',
				    html : true,
				    content : '<i class="fa fa-plus" id="add_achivement" aria-hidden="true"></i><i class="fa fa-trash del_achivement" aria-hidden="true"></i>'
				});
				$('#education_heading').popover
				({
				    placement : 'top',
				    html : true,
				    content : '<i class="fa fa-plus" id="add_achivement" aria-hidden="true"></i><i class="fa fa-trash del_achivement" aria-hidden="true"></i>'
				});
				new_div = '#education_div'+ac_count;
				ac_count++;	
			});
			$('html, body').animate({scrollTop: $(new_div).offset().top}, 1500);
			$('.datepicker,.lnr-calendar-full').datepicker();
      		$('#education_div'+ed_count).css("background-color","white");
			deleteDivById();
		}
		else
		{
			alert("Already there");		
		}
	});

});


$( function() {
    $('.datepicker,.lnr-calendar-full').datepicker();
});
